/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xosFmtIO_H_
#define xosFmtIO_H_
#include "X2C.h"

extern void X2C_StdOutS(char [], unsigned long);

extern void X2C_StdOutD(unsigned long, unsigned long);

extern void X2C_StdOutH(unsigned long, unsigned long);

extern void X2C_DecToStr(char [], unsigned long *, unsigned long);

extern void X2C_HexToStr(char [], unsigned long *, unsigned long);


#endif /* xosFmtIO_H_ */
