/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrAReal.c Jun  7 14:37:34 2019" */
#include "xrAReal.h"
#define xrAReal_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern long X2C_ENTIER(double x)
{
   long i;
   if (x<(-2.147483648E+9) || x>2.147483647E+9) X2C_TRAP(1L);
   i=(long)x;
   if ((double)i>x) --i;
   return i;
} /* end X2C_ENTIER() */


extern long X2C_TRUNCI(double x, long min0, long max0)
{
   long i;
   if (x<(double)min0 || x>(double)max0) X2C_TRAP(1L);
   i=(long)x;
   if (x>0.0) {
      if ((double)i>x) --i;
   }
   else if ((double)i<x) ++i;
   return i;
} /* end X2C_TRUNCI() */


extern unsigned long X2C_TRUNCC(double x, unsigned long min0,
                unsigned long max0)
{
   unsigned long i;
   if (x<(double)min0 || x>(double)max0) X2C_TRAP(1L);
   i=(unsigned long)x;
   if ((double)i>x) --i;
   return i;
} /* end X2C_TRUNCC() */

