/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xosMalloc_H_
#define xosMalloc_H_
#include "X2C.h"

extern void X2C_InitHeap(unsigned long, char);

extern X2C_ADDRESS X2C_malloc(unsigned long);

extern void X2C_free(X2C_ADDRESS, unsigned long);

extern X2C_ADDRESS X2C_gmalloc(unsigned long);

extern void X2C_gfree(X2C_ADDRESS);

extern void X2C_DestroyHeap(void);


#endif /* xosMalloc_H_ */
