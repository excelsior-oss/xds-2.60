/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosMalloc.c Jun  7 14:37:34 2019" */
#include "xosMalloc.h"
#define xosMalloc_C_
#include "xPOSIX.h"


extern X2C_ADDRESS X2C_malloc(unsigned long size)
{
   return malloc(size);
} /* end X2C_malloc() */


extern void X2C_free(X2C_ADDRESS adr, unsigned long size)
{
   free(adr);
} /* end X2C_free() */


extern X2C_ADDRESS X2C_gmalloc(unsigned long size)
{
   return malloc(size);
} /* end X2C_gmalloc() */


extern void X2C_gfree(X2C_ADDRESS p)
{
   free(p);
} /* end X2C_gfree() */


extern void X2C_InitHeap(unsigned long limit, char isIncr)
{
} /* end X2C_InitHeap() */


extern void X2C_ZEROMEM(X2C_ADDRESS adr, unsigned long qsize)
{
   memset(adr, 0, qsize*4UL);
} /* end X2C_ZEROMEM() */


extern void X2C_DestroyHeap(void)
{
} /* end X2C_DestroyHeap() */

