/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcChecks.c Jun  7 14:37:34 2019" */
#include "xrcChecks.h"
#define xrcChecks_C_
#include "xmRTS.h"
#include "M2EXCEPTION.h"


extern unsigned short X2C_CHKINX_F(unsigned long i, unsigned short length)
{
   if (i>=(unsigned long)length) X2C_TRAP_F(0L);
   return (unsigned short)i;
} /* end X2C_CHKINX_F() */


extern unsigned long X2C_CHKINXL_F(unsigned long i, unsigned long length)
{
   if (i>=length) X2C_TRAP_F(0L);
   return i;
} /* end X2C_CHKINXL_F() */


extern short X2C_CHKS_F(short i)
{
   if (i<0) X2C_TRAP_F(1L);
   return i;
} /* end X2C_CHKS_F() */


extern long X2C_CHKSL_F(long i)
{
   if (i<0L) X2C_TRAP_F(1L);
   return i;
} /* end X2C_CHKSL_F() */


extern short X2C_CHK_F(short a, short min0, short max0)
{
   if (a<min0 || a>max0) X2C_TRAP_F(1L);
   return a;
} /* end X2C_CHK_F() */


extern long X2C_CHKL_F(long a, long min0, long max0)
{
   if (a<min0 || a>max0) X2C_TRAP_F(1L);
   return a;
} /* end X2C_CHKL_F() */


extern unsigned short X2C_CHKU_F(unsigned short a, unsigned short min0,
                unsigned short max0)
{
   if (a<min0 || a>max0) X2C_TRAP_F(1L);
   return a;
} /* end X2C_CHKU_F() */


extern unsigned long X2C_CHKUL_F(unsigned long a, unsigned long min0,
                unsigned long max0)
{
   if (a<min0 || a>max0) X2C_TRAP_F(1L);
   return a;
} /* end X2C_CHKUL_F() */


extern X2C_pVOID X2C_CHKNIL_F(X2C_pVOID p)
{
   if (p==0) X2C_TRAP_F(3L);
   return p;
} /* end X2C_CHKNIL_F() */


extern X2C_PROC X2C_CHKPROC_F(X2C_PROC p)
{
   if (p==0) X2C_TRAP_F(3L);
   return p;
} /* end X2C_CHKPROC_F() */

