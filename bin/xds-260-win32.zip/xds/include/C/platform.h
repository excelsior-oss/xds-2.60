/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef platform_H_
#define platform_H_
#include "X2C.h"

extern char pl_unix;

extern char pl_vms;

extern char pl_msdos;

extern char pl_amiga;

extern char pl_fatfs;

extern char extSep;

extern char pathSep;

extern char pathBeg;

extern char pathEnd;

extern char drvSep;

extern char lineSep[8];

extern char textSep[8];

#define chr_SEP0 '\012'
#define SEP0 "\012"

#define chr_SEP1 0
#define SEP1 ""

extern char IsPathDelim(char);


#endif /* platform_H_ */
