/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosExec.c Jun  7 14:37:34 2019" */
#include "xosExec.h"
#define xosExec_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "xlibOS.h"
#include "X2C.h"
#include "xrtsOS.h"


static void put_in_quotes(X2C_pCHAR to, X2C_pCHAR a)
{
   *to = '\"';
   to = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)to+(long)1UL);
   while (*a) {
      *to = *a;
      to = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)to+(long)1UL);
      a = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)a+(long)1UL);
   }
   *to = '\"';
   to = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)to+(long)1UL);
   *to = 0;
} /* end put_in_quotes() */


extern long X2C_Execute(X2C_pCHAR cmd, X2C_pCHAR args, int overlay,
                unsigned long * exitcode)
{
   xPOSIX_PCHAR argv[256];
   long i;
   long rc;
   unsigned long bsz;
   i = 1L;
   for (;;) {
      while ((unsigned char)(*args)<=' ') {
         if (*args==0) goto loop_exit;
         args = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)args+(long)1UL)
                ;
      }
      argv[i] = (xPOSIX_PCHAR)args;
      ++i;
      while ((unsigned char)(*args)>' ') {
         args = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)args+(long)1UL)
                ;
      }
      if (*args==0) break;
      *args = 0;
      args = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)args+(long)1UL);
   }
   loop_exit:;
   argv[i] = 0;
   bsz = strlen(cmd)+2U+1U;
   argv[0U] = (xPOSIX_PCHAR)X2C_malloc(bsz);
   put_in_quotes((X2C_pCHAR)argv[0U], cmd);
   #if defined(__WATCOMC__)
   cmd = (X2C_pCHAR)argv[0U];
   #endif
   if (overlay) {
      #if defined(_msdos)
      rc = spawnv(P_WAIT, cmd, argv);
      #else
      rc = execv(cmd, argv);
      #endif
   }
   else rc = spawnv(P_WAIT, cmd, argv);
   X2C_free((X2C_ADDRESS)argv[0U], bsz);
   if (rc<0L) return errno;
   else {
      *exitcode = (unsigned long)rc;
      return 0L;
   }
   return 0;
} /* end X2C_Execute() */


extern long X2C_ExecuteNoWindow(X2C_pCHAR cmd, X2C_pCHAR args, int overlay,
                unsigned long * exitcode)
{
   return X2C_Execute(cmd, args, overlay, exitcode);
} /* end X2C_ExecuteNoWindow() */


extern long X2C_Command(X2C_pCHAR cmd, unsigned long * exitcode)
{
   long rc;
   rc = system(cmd);
   if (rc<0L) return errno;
   else {
      *exitcode = (unsigned long)rc;
      return 0L;
   }
   return 0;
} /* end X2C_Command() */

