/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosFmtNL.c Jun  7 14:37:34 2019" */
#include "xosFmtNL.h"
#define xosFmtNL_C_
#include "xPOSIX.h"


extern void X2C_StdOutN(void)
{
   printf("\n");
} /* end X2C_StdOutN() */

