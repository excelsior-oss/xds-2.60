/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcIncDec64_H_
#define xrcIncDec64_H_
#include "X2C.h"

extern X2C_INT64 X2C_INC64(X2C_INT64 *, X2C_INT64, X2C_INT64, X2C_INT64);

extern X2C_CARD64 X2C_INCU64(X2C_CARD64 *, X2C_CARD64, X2C_CARD64,
                X2C_CARD64);

extern X2C_INT64 X2C_DEC64(X2C_INT64 *, X2C_INT64, X2C_INT64, X2C_INT64);

extern X2C_CARD64 X2C_DECU64(X2C_CARD64 *, X2C_CARD64, X2C_CARD64,
                X2C_CARD64);


#endif /* xrcIncDec64_H_ */
