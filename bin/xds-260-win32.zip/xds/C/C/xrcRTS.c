/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcRTS.c Jun  7 14:37:34 2019" */
#include "xrcRTS.h"
#define xrcRTS_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "M2EXCEPTION.h"
#include "X2C.h"


extern char X2C_IN(unsigned long i, unsigned short bits, unsigned long set)
{
   if (i<(unsigned long)bits) return (((1L << (int)i) & set) != 0);
   return 0;
} /* end X2C_IN() */


extern unsigned long X2C_SET(unsigned long a, unsigned long b,
                unsigned short bits)
{
   if ((a>b || a>=(unsigned long)bits) || b>=(unsigned long)bits) {
      X2C_TRAP(1L);
   }
   return ((X2C_SET32) ((2L<<(int)b) - (1L<<(int)a)));
   return 0UL;
} /* end X2C_SET() */


extern void X2C_PCOPY(X2C_pVOID * p, size_t size)
{
   X2C_ADDRESS a;
   X2C_ALLOCATE(&a, size);
   if (a==0) X2C_TRAP((long)X2C_noMemoryException);
   memcpy(a, (X2C_ADDRESS)*p, size);
   *p = (X2C_pVOID)a;
} /* end X2C_PCOPY() */


extern void X2C_PFREE(X2C_pVOID p)
{
   X2C_ADDRESS a;
   a = (X2C_ADDRESS)p;
   X2C_DEALLOCATE(&a);
} /* end X2C_PFREE() */


extern short X2C_PROT(void)
{
   X2C_Coroutine current;
   current = X2C_GetCurrent();
   return current->prot;
} /* end X2C_PROT() */

