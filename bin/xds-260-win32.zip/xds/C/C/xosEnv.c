/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xosEnv.c Jun  7 14:37:34 2019" */
#include "xosEnv.h"
#define xosEnv_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "X2C.h"

typedef char * PSTR;


extern unsigned long X2C_EnvStringLength(X2C_pCHAR name)
{
   X2C_pCHAR p;
   p = (X2C_pCHAR)getenv(name);
   if (p==0) return 0UL;
   return strlen(p);
} /* end X2C_EnvStringLength() */


extern void X2C_EnvString(X2C_pCHAR name, X2C_pCHAR buf, unsigned long blen)
{
   X2C_pCHAR p;
   PSTR t;
   PSTR f;
   unsigned long i;
   p = (X2C_pCHAR)getenv(name);
   if (p==0) return;
   f = (PSTR)p;
   t = (PSTR)buf;
   i = 0UL;
   while (i<blen && f[i]) {
      t[i] = f[i];
      ++i;
   }
   if (i<blen) t[i] = 0;
} /* end X2C_EnvString() */

static char EmptyName[1] = "";


extern X2C_pCHAR X2C_GetProgramName(void)
{
   if (X2C_argc==0) return EmptyName;
   else return (X2C_pCHAR)(*X2C_argv);
   return 0;
} /* end X2C_GetProgramName() */

