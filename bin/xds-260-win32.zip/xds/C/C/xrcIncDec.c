/* XDS v2.60: Copyright (c) 1999-2011 Excelsior, LLC. All Rights Reserved. */
/* "@(#)xrcIncDec.c Jun  7 14:37:34 2019" */
#include "xrcIncDec.h"
#define xrcIncDec_C_
#include "X2C.h"
#include "M2EXCEPTION.h"


extern char X2C_INCC(char * x, unsigned char y, char min0, char max0)
{
   short i;
   i = (short)(unsigned char)*x+(short)y;
   if ((long)i<(long)(unsigned long)(unsigned char)min0 || (long)i>(long)
                (unsigned long)(unsigned char)max0) X2C_TRAP(1L);
   *x = (char)i;
   return *x;
} /* end X2C_INCC() */


extern signed char X2C_INCS(signed char * x, signed char y, signed char min0,
                 signed char max0)
{
   short i;
   i = (short)*x+(short)y;
   if (i<(short)min0 || i>(short)max0) X2C_TRAP(1L);
   *x = (signed char)i;
   return *x;
} /* end X2C_INCS() */


extern short X2C_INCI(short * x, short y, short min0, short max0)
{
   long i;
   i = (long)*x+(long)y;
   if (i<(long)min0 || i>(long)max0) X2C_TRAP(1L);
   *x = (short)i;
   return *x;
} /* end X2C_INCI() */


extern long X2C_INC(long * x, long y, long min0, long max0)
{
   long i;
   if (y>0L) {
      if (X2C_max_longint-y<*x) X2C_TRAP(1L);
   }
   else if (X2C_min_longint-y>*x) X2C_TRAP(1L);
   i = *x+y;
   if (i<min0 || i>max0) X2C_TRAP(1L);
   *x = i;
   return *x;
} /* end X2C_INC() */


extern unsigned char X2C_INCUS(unsigned char * x, unsigned char y,
                unsigned char min0, unsigned char max0)
{
   unsigned short i;
   i = (unsigned short)*x+(unsigned short)y;
   if (i<(unsigned short)min0 || i>(unsigned short)max0) X2C_TRAP(1L);
   *x = (unsigned char)i;
   return *x;
} /* end X2C_INCUS() */


extern unsigned short X2C_INCUI(unsigned short * x, unsigned short y,
                unsigned short min0, unsigned short max0)
{
   unsigned long i;
   i = (unsigned long)*x+(unsigned long)y;
   if (i<(unsigned long)min0 || i>(unsigned long)max0) X2C_TRAP(1L);
   *x = (unsigned short)i;
   return *x;
} /* end X2C_INCUI() */


extern unsigned long X2C_INCU(unsigned long * x, unsigned long y,
                unsigned long min0, unsigned long max0)
{
   unsigned long i;
   if (X2C_max_longcard-y<*x) X2C_TRAP(1L);
   i = *x+y;
   if (i<min0 || i>max0) X2C_TRAP(1L);
   *x = i;
   return *x;
} /* end X2C_INCU() */


extern char X2C_DECC(char * x, unsigned char y, char min0, char max0)
{
   short i;
   i = (short)(unsigned char)*x-(short)y;
   if ((long)i<(long)(unsigned long)(unsigned char)min0 || (long)i>(long)
                (unsigned long)(unsigned char)max0) X2C_TRAP(1L);
   *x = (char)i;
   return *x;
} /* end X2C_DECC() */


extern signed char X2C_DECS(signed char * x, signed char y, signed char min0,
                 signed char max0)
{
   short i;
   i = (short)*x-(short)y;
   if (i<(short)min0 || i>(short)max0) X2C_TRAP(1L);
   *x = (signed char)i;
   return *x;
} /* end X2C_DECS() */


extern short X2C_DECI(short * x, short y, short min0, short max0)
{
   long i;
   i = (long)*x-(long)y;
   if (i<(long)min0 || i>(long)max0) X2C_TRAP(1L);
   *x = (short)i;
   return *x;
} /* end X2C_DECI() */


extern long X2C_DEC(long * x, long y, long min0, long max0)
{
   if (y<0L) {
      if (X2C_max_longint+y<*x) X2C_TRAP(1L);
   }
   else if (X2C_min_longint+y>*x) X2C_TRAP(1L);
   *x -= y;
   if (*x<min0 || *x>max0) X2C_TRAP(1L);
   return *x;
} /* end X2C_DEC() */


extern unsigned char X2C_DECUS(unsigned char * x, unsigned char y,
                unsigned char min0, unsigned char max0)
{
   if (y>*x) X2C_TRAP(1L);
   *x -= y;
   if (*x<min0 || *x>max0) X2C_TRAP(1L);
   return *x;
} /* end X2C_DECUS() */


extern unsigned short X2C_DECUI(unsigned short * x, unsigned short y,
                unsigned short min0, unsigned short max0)
{
   if (y>*x) X2C_TRAP(1L);
   *x -= y;
   if (*x<min0 || *x>max0) X2C_TRAP(1L);
   return *x;
} /* end X2C_DECUI() */


extern unsigned long X2C_DECU(unsigned long * x, unsigned long y,
                unsigned long min0, unsigned long max0)
{
   unsigned long i;
   if (y>*x) X2C_TRAP(1L);
   i = *x-y;
   if (i<min0 || i>max0) X2C_TRAP(1L);
   *x = i;
   return *x;
} /* end X2C_DECU() */

